package com.jackdev.bluelight

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

data class Game(val id: String, val name: String, val cover: String?, val pkg: String, val rom: String?)

object Banner { var text by mutableStateOf<String?>(null) }
object Refresh { var tick by mutableIntStateOf(0) }
object NotifState { var count by mutableIntStateOf(0) }

class AppState(ctx: Context) {
    private val sp = ctx.getSharedPreferences("blue", Context.MODE_PRIVATE)

    var wallpaper by mutableStateOf<String?>(sp.getString("wall", null))
    var scale by mutableFloatStateOf(sp.getFloat("scale", 1f))
    var showIntro by mutableStateOf(sp.getBoolean("intro", true))
    var clockLeft by mutableStateOf(sp.getBoolean("clockLeft", false))
    var musicPkg by mutableStateOf<String?>(sp.getString("music", null))
    var wallVideo by mutableStateOf<String?>(sp.getString("wvideo", null))
    var wallFit by mutableIntStateOf(sp.getInt("wfit", 0))
    var vStart by mutableIntStateOf(sp.getInt("vstart", 0))
    var vEnd by mutableIntStateOf(sp.getInt("vend", Int.MAX_VALUE))
    var tile3d by mutableStateOf(sp.getBoolean("t3d", false))
    var tileGlow by mutableStateOf(sp.getBoolean("tglow", false))
    var tileHl by mutableStateOf(sp.getBoolean("thl", true))
    var ovOn by mutableStateOf(sp.getBoolean("ovOn", true))
    var ovFps by mutableStateOf(sp.getBoolean("ovFps", true))
    var ovCpu by mutableStateOf(sp.getBoolean("ovCpu", true))
    var ovGpu by mutableStateOf(sp.getBoolean("ovGpu", true))
    var ovRam by mutableStateOf(sp.getBoolean("ovRam", true))
    var ovTemp by mutableStateOf(sp.getBoolean("ovTemp", true))

    val dock = mutableStateListOf<String>()
    val games = mutableStateListOf<Game>()

    init {
        val d = sp.getString("dock", null)
        if (d == null) {
            dock.addAll(listOf("com.android.chrome", "com.android.vending", "com.google.android.youtube", "com.whatsapp", "com.android.settings"))
        } else {
            val a = JSONArray(d)
            for (i in 0 until a.length()) dock.add(a.getString(i))
        }
        val g = sp.getString("games", null)
        if (g != null) {
            val a = JSONArray(g)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                games.add(
                    Game(
                        o.getString("id"), o.getString("name"),
                        if (o.isNull("cover")) null else o.getString("cover"),
                        o.getString("pkg"),
                        if (o.isNull("rom")) null else o.getString("rom")
                    )
                )
            }
        }
    }

    fun save() {
        val e = sp.edit()
        e.putString("wall", wallpaper)
        e.putFloat("scale", scale)
        e.putBoolean("intro", showIntro)
        e.putBoolean("clockLeft", clockLeft)
        e.putString("music", musicPkg)
        e.putString("wvideo", wallVideo)
        e.putInt("wfit", wallFit)
        e.putInt("vstart", vStart)
        e.putInt("vend", vEnd)
        e.putBoolean("t3d", tile3d)
        e.putBoolean("tglow", tileGlow)
        e.putBoolean("thl", tileHl)
        e.putBoolean("ovOn", ovOn)
        e.putBoolean("ovFps", ovFps)
        e.putBoolean("ovCpu", ovCpu)
        e.putBoolean("ovGpu", ovGpu)
        e.putBoolean("ovRam", ovRam)
        e.putBoolean("ovTemp", ovTemp)
        e.putString("dock", JSONArray(dock.toList()).toString())
        val arr = JSONArray()
        for (g in games) {
            val o = JSONObject()
            o.put("id", g.id)
            o.put("name", g.name)
            o.put("cover", g.cover ?: JSONObject.NULL)
            o.put("pkg", g.pkg)
            o.put("rom", g.rom ?: JSONObject.NULL)
            arr.put(o)
        }
        e.putString("games", arr.toString())
        e.apply()
    }
}
