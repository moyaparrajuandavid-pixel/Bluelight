package com.jackdev.bluelight

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Release(val version: String, val build: Int, val notes: List<String>)

/** Agrega aquí cada actualización nueva (la más reciente primero). */
val RELEASES = listOf(
    Release("1.3", 4, listOf(
        "Intro nueva en video, predeterminada de la app, con desvanecido hacia el inicio",
        "Modo 3D detallado con piso de hielo iluminado (opcional, en ajustes)",
        "Brillo, iluminación del piso y reflejos (opcional)",
        "Destacar al tocar o seleccionar (opcional)",
        "Los iconos de apps ya no se estiran; solo las portadas de juegos llenan el cuadro",
        "Versión y novedades en ajustes"
    )),
    Release("1.2", 3, listOf(
        "Carga más rápida de apps e imágenes al volver a la app",
        "Fondo de video desde la galería, con recorte de hasta 20 segundos",
        "Ajuste del fondo: estirar, llenar o ajustar completo",
        "Botón Salir en ajustes y en agregar juego",
        "Fondo predeterminado de Blue Light"
    )),
    Release("1.1", 2, listOf(
        "Editor de portadas: mover, acercar y girar",
        "Aplicaciones: botones Ver todas y Buscar",
        "Imagen de la canción en el reproductor",
        "Hora más grande",
        "Textos Activado y Desactivado en los ajustes"
    )),
    Release("1.0", 1, listOf(
        "Primera versión: inicio estilo consola, juegos con carátula, monitor de CPU, RAM y temperatura, aviso de mando conectado y música"
    ))
)

@Composable
fun ChangelogScreen(onClose: () -> Unit) {
    BackHandler(onBack = onClose)
    Column(
        Modifier.fillMaxSize().background(Color(0xF2051434))
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(horizontal = 40.dp, vertical = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Novedades", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            PillBtn("Cerrar ✕", onClose)
        }
        LazyColumn(Modifier.fillMaxSize().padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(RELEASES) { r ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Versión ${r.version} (compilación ${r.build})", color = Blue, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    r.notes.forEach { Text("• $it", color = Color.White, fontSize = 14.sp) }
                }
            }
        }
    }
}
