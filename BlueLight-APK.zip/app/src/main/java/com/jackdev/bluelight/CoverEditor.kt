package com.jackdev.bluelight

import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

private fun renderCrop(src: Bitmap, s: Float, z: Float, off: Offset): Bitmap {
    val out = 512
    val k = out / s
    val b = maxOf(s / src.width, s / src.height)
    val m = Matrix()
    m.postTranslate(-src.width / 2f, -src.height / 2f)
    m.postScale(b * z * k, b * z * k)
    m.postTranslate(out / 2f + off.x * k, out / 2f + off.y * k)
    val res = Bitmap.createBitmap(out, out, Bitmap.Config.ARGB_8888)
    android.graphics.Canvas(res).drawBitmap(src, m, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
    return res
}

@Composable
fun CoverEditor(uri: String, onDone: (String?) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var z by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    LaunchedEffect(uri) { bmp = withContext(Dispatchers.IO) { loadRaw(ctx, uri, 1600) } }
    val s = with(LocalDensity.current) { 220.dp.toPx() }
    BackHandler { onDone(null) }

    fun clamp(o: Offset, zz: Float): Offset {
        val b = bmp ?: return o
        val base = maxOf(s / b.width, s / b.height)
        val mx = ((b.width * base * zz - s) / 2f).coerceAtLeast(0f)
        val my = ((b.height * base * zz - s) / 2f).coerceAtLeast(0f)
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }
    fun rotate() {
        val b = bmp ?: return
        bmp = Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(90f) }, true)
        z = 1f
        off = Offset.Zero
    }
    fun zoomBy(f: Float) {
        z = (z * f).coerceIn(1f, 5f)
        off = clamp(off, z)
    }

    Row(
        Modifier.fillMaxSize().background(Color(0xF2051434))
            .pointerInput(Unit) { detectTapGestures { } }.padding(16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(220.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF222222))
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        z = (z * zoom).coerceIn(1f, 5f)
                        off = clamp(off + pan, z)
                    }
                }
        ) {
            val b0 = bmp
            if (b0 != null) {
                val img = remember(b0) { b0.asImageBitmap() }
                Image(
                    img, null,
                    Modifier.fillMaxSize().graphicsLayer(scaleX = z, scaleY = z, translationX = off.x, translationY = off.y),
                    contentScale = ContentScale.Crop
                )
            }
        }
        Spacer(Modifier.width(28.dp))
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Ajusta la carátula", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Arrastra para mover y pellizca para acercar", color = Color(0xCCFFFFFF), fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillBtn("Girar ⟳") { rotate() }
                PillBtn("Acercar +") { zoomBy(1.2f) }
                PillBtn("Alejar −") { zoomBy(1f / 1.2f) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillBtn("OK ✅") {
                    val b = bmp
                    if (b != null) scope.launch {
                        val r = withContext(Dispatchers.IO) {
                            val crop = renderCrop(b, s, z, off)
                            val dir = File(ctx.filesDir, "covers")
                            dir.mkdirs()
                            val file = File(dir, UUID.randomUUID().toString() + ".jpg")
                            FileOutputStream(file).use { crop.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                            Uri.fromFile(file).toString()
                        }
                        onDone(r)
                    }
                }
                PillBtn("Cancelar") { onDone(null) }
            }
        }
    }
}
