package com.jackdev.bluelight

import android.media.MediaPlayer
import android.net.Uri
import android.widget.FrameLayout
import android.widget.VideoView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay

/** Intro predeterminada de Blue Light (video dentro de la app). Al terminar se desvanece hacia el inicio. */
@Composable
fun IntroScreen(onFade: () -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val alpha = remember { Animatable(1f) }
    var ended by remember { mutableStateOf(false) }
    val uri = remember { "android.resource://${ctx.packageName}/${R.raw.intro}" }

    LaunchedEffect(ended) {
        if (ended) {
            onFade()
            delay(300)
            alpha.animateTo(0f, tween(1300))
            onDone()
        }
    }

    Box(Modifier.fillMaxSize().graphicsLayer { this.alpha = alpha.value }.background(Color.Black)) {
        AndroidView(
            factory = { c ->
                val clip = ClipView(c, true)
                clip.setVideoURI(Uri.parse(uri))
                clip.setOnPreparedListener { mp ->
                    try { mp.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING) } catch (e: Exception) { }
                }
                clip.setOnCompletionListener { ended = true }
                clip.setOnErrorListener { _, _, _ -> ended = true; true }
                clip.start()
                val box = FrameLayout(c)
                box.addView(clip, FrameLayout.LayoutParams(-1, -1))
                box
            },
            onRelease = { box -> (box.getChildAt(0) as? VideoView)?.stopPlayback() },
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier.fillMaxSize().clickable(remember { MutableInteractionSource() }, null) { onFade(); onDone() }
        )
    }
}
