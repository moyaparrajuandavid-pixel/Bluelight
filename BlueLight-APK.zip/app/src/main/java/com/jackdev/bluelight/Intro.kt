package com.jackdev.bluelight

import android.graphics.Bitmap
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private class Fly(
    val bx: Float, val by: Float, val ph: Float, val ph2: Float,
    val amp: Float, val appear: Float, val sz: Float
)

private fun smooth(x: Float): Float {
    val c = x.coerceIn(0f, 1f)
    return c * c * (3f - 2f * c)
}

private fun mix(a: Float, b: Float, k: Float) = a + (b - a) * k

private fun textPoints(w: Int, h: Int, n: Int): List<Offset> {
    val txt = "Blue Light"
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textSize = 100f
    }
    paint.textSize = 100f * (w * 0.55f) / paint.measureText(txt)
    val bw = paint.measureText(txt).toInt() + 4
    val fm = paint.fontMetrics
    val bh = (fm.descent - fm.ascent).toInt() + 4
    val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
    android.graphics.Canvas(bmp).drawText(txt, 2f, -fm.ascent + 2f, paint)
    val px = IntArray(bw * bh)
    bmp.getPixels(px, 0, bw, 0, 0, bw, bh)
    val step = (bw / 120).coerceAtLeast(2)
    val pts = ArrayList<Offset>()
    var y = 0
    while (y < bh) {
        var x = 0
        while (x < bw) {
            if ((px[y * bw + x] ushr 24) > 128) pts.add(Offset(x.toFloat(), y.toFloat()))
            x += step
        }
        y += step
    }
    if (pts.isEmpty()) return List(n) { Offset(w / 2f, h / 2f) }
    pts.shuffle(Random(3))
    val ox = (w - bw) / 2f
    val oy = (h - bh) / 2f
    return List(n) { i -> val p = pts[i % pts.size]; Offset(p.x + ox, p.y + oy) }
}

@Composable
fun IntroScreen(onDone: () -> Unit) {
    var box by remember { mutableStateOf(IntSize.Zero) }
    var t by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (t < 13f) {
            val n = withFrameNanos { it }
            t = (n - start) / 1_000_000_000f
        }
        onDone()
    }

    val flies = remember {
        val r = Random(11)
        List(520) { i ->
            Fly(
                r.nextFloat(), 0.3f + r.nextFloat() * 0.65f,
                r.nextFloat() * 6.28f, r.nextFloat() * 6.28f,
                12f + r.nextFloat() * 40f,
                if (i < 110) 1.5f + r.nextFloat() * 4.5f else 6.5f + r.nextFloat() * 1.5f,
                2f + r.nextFloat() * 2.5f
            )
        }
    }
    val grass = remember {
        val r = Random(5)
        List(150) { floatArrayOf(r.nextFloat(), r.nextFloat()) }
    }
    val targets = remember(box) {
        if (box.width == 0) emptyList() else textPoints(box.width, box.height, flies.size)
    }

    Canvas(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onSizeChanged { box = it }
            .clickable(remember { MutableInteractionSource() }, null) { onDone() }
    ) {
        val tt = t
        val w = size.width
        val h = size.height
        val u = h / 540f
        val grassA = 1f - smooth((tt - 6f) / 1.5f)

        if (grassA > 0.01f) {
            drawRect(
                Brush.verticalGradient(listOf(Color(0xFF020611), Color(0xFF03101F), Color.Black)),
                alpha = grassA
            )
            val n = grass.size
            for (i in 0 until n) {
                val g = grass[i]
                val bxp = (i + 0.5f) / n * w
                val hgt = h * (0.1f + 0.22f * g[0])
                val sway = sin(tt * 1.3f + i * 0.35f + g[1] * 6f) * (14f + 30f * g[0]) * u *
                    (0.6f + 0.4f * sin(tt * 0.4f + i * 0.05f))
                val path = Path().apply {
                    moveTo(bxp, h)
                    quadraticBezierTo(bxp + sway * 0.3f, h - hgt * 0.6f, bxp + sway, h - hgt)
                }
                val col = when (i % 3) {
                    0 -> Color(0xFF0D3345)
                    1 -> Color(0xFF082432)
                    else -> Color(0xFF051620)
                }
                drawPath(
                    path, col.copy(alpha = grassA),
                    style = Stroke(width = (3f + 4f * g[1]) * u, cap = StrokeCap.Round)
                )
            }
        }

        flies.forEachIndexed { i, f ->
            val a0 = smooth((tt - f.appear) / 1.5f)
            if (a0 > 0f) {
                val k = if (targets.isEmpty()) 0f else smooth((tt - 7.5f - f.ph / 6.28f * 1.2f) / 2.5f)
                val wx = (sin(tt * 0.7f + f.ph) * f.amp + sin(tt * 1.9f + f.ph2) * f.amp * 0.3f) * u
                val wy = (cos(tt * 0.5f + f.ph2) * f.amp * 0.7f) * u
                var x = f.bx * w + wx
                var y = f.by * h + wy
                if (k > 0f) {
                    val tg = targets[i]
                    x = mix(x, tg.x, k) + sin(tt * 3f + f.ph) * 1.5f * k
                    y = mix(y, tg.y, k) + cos(tt * 3f + f.ph2) * 1.5f * k
                }
                val blink = mix(0.65f + 0.35f * sin(tt * 2.2f + f.ph * 3f), 1f, k)
                val al = (a0 * blink).coerceIn(0f, 1f)
                val c = Offset(x, y)
                val s = f.sz * u
                drawCircle(Color(0xFF3DA5FF).copy(alpha = al * 0.16f), s * 5f, c)
                drawCircle(Color(0xFF6CC4FF).copy(alpha = al * 0.35f), s * 2.5f, c)
                drawCircle(Color(0xFFCFEFFF).copy(alpha = al), s * 0.9f, c)
            }
        }
    }
}
