package com.jackdev.bluelight

import android.content.Context
import android.content.Intent
import android.hardware.input.InputManager
import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private lateinit var st: AppState
    private lateinit var im: InputManager

    private val listener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) {
            val d = InputDevice.getDevice(deviceId)
            if (isPad(d)) Banner.text = "Mando conectado ✅  ${padName(d!!.name)}"
        }
        override fun onInputDeviceRemoved(deviceId: Int) {}
        override fun onInputDeviceChanged(deviceId: Int) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        st = AppState(this)
        im = getSystemService(Context.INPUT_SERVICE) as InputManager
        im.registerInputDeviceListener(listener, null)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Blue)) { Root(st) }
        }
    }

    override fun onResume() {
        super.onResume()
        stopService(Intent(this, OverlayService::class.java))
        Refresh.tick++
    }

    override fun onPause() {
        st.save()
        super.onPause()
    }

    override fun onDestroy() {
        im.unregisterInputDeviceListener(listener)
        super.onDestroy()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val code = when (e.keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> KeyEvent.KEYCODE_DPAD_CENTER
            KeyEvent.KEYCODE_BUTTON_B -> KeyEvent.KEYCODE_BACK
            else -> return super.dispatchKeyEvent(e)
        }
        val k = KeyEvent(
            e.downTime, e.eventTime, e.action, code, e.repeatCount,
            e.metaState, e.deviceId, e.scanCode, e.flags, e.source
        )
        return super.dispatchKeyEvent(k)
    }
}

@Composable
fun Root(st: AppState) {
    val ctx = LocalContext.current
    var screen by remember { mutableStateOf(if (st.showIntro) "intro" else "home") }
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    LaunchedEffect(Refresh.tick) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    LaunchedEffect(Banner.text) {
        if (Banner.text != null) { delay(3500); Banner.text = null }
    }
    val d = LocalDensity.current
    CompositionLocalProvider(LocalDensity provides Density(d.density * st.scale, d.fontScale)) {
        Box(Modifier.fillMaxSize()) {
            when (screen) {
                "intro" -> IntroScreen { screen = "home" }
                "settings" -> SettingsScreen(st, apps) { screen = "home" }
                "add" -> AddGameScreen(st, apps) { screen = "home" }
                else -> HomeScreen(st, apps, { screen = "settings" }, { screen = "add" })
            }
            val b = Banner.text
            if (b != null) {
                Box(
                    Modifier.align(Alignment.TopCenter).padding(top = 12.dp)
                        .clip(RoundedCornerShape(20.dp)).background(Color(0xDD0B2A5C))
                        .padding(horizontal = 20.dp, vertical = 10.dp)
                ) { Text(b, color = Color.White) }
            }
        }
    }
}
