package com.jackdev.bluelight

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.view.View
import android.widget.VideoView
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

class FillVideoView(ctx: Context) : VideoView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(View.getDefaultSize(0, widthMeasureSpec), View.getDefaultSize(0, heightMeasureSpec))
    }
}

@Composable
fun VideoBackground(uri: String, modifier: Modifier) {
    AndroidView(
        factory = { c ->
            FillVideoView(c).apply {
                setVideoURI(Uri.parse(uri))
                setOnPreparedListener { mp ->
                    mp.isLooping = true
                    mp.setVolume(0f, 0f)
                    try { mp.setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING) } catch (e: Exception) { }
                }
                setOnErrorListener { _, _, _ -> true }
                start()
            }
        },
        modifier = modifier
    )
}
