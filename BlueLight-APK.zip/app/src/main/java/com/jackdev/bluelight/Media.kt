package com.jackdev.bluelight

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView

class ClipView(ctx: Context, val fill: Boolean) : VideoView(ctx) {
    var startMs = 0
    var endMs = Int.MAX_VALUE
    var tick = 0
    private val loopHandler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            try { if (isPlaying && currentPosition >= endMs) seekTo(startMs) } catch (e: Exception) { }
            loopHandler.postDelayed(this, 150)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        loopHandler.post(poll)
    }

    override fun onDetachedFromWindow() {
        loopHandler.removeCallbacks(poll)
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (fill) {
            setMeasuredDimension(View.getDefaultSize(0, widthMeasureSpec), View.getDefaultSize(0, heightMeasureSpec))
        } else {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        }
    }

    fun restart() {
        seekTo(startMs)
        start()
    }
}

/** fit: 0 = estirar, 1 = llenar (recorta), 2 = ajustar completo (barras). Siempre sin sonido y en bucle. */
@Composable
fun ClipVideo(uri: String, startMs: Int, endMs: Int, fit: Int, modifier: Modifier, tick: Int = 0) {
    key(uri, fit) {
        AndroidView(
            factory = { c ->
                val clip = ClipView(c, fit != 2)
                clip.startMs = startMs
                clip.endMs = endMs
                clip.tick = tick
                clip.setVideoURI(Uri.parse(uri))
                clip.setOnPreparedListener { mp ->
                    mp.setVolume(0f, 0f)
                    try {
                        mp.setVideoScalingMode(
                            if (fit == 1) MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                            else MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT
                        )
                    } catch (e: Exception) { }
                    clip.seekTo(clip.startMs)
                }
                clip.setOnCompletionListener { clip.seekTo(clip.startMs); clip.start() }
                clip.setOnErrorListener { _, _, _ -> true }
                clip.start()
                val box = FrameLayout(c)
                val lp = if (fit != 2) FrameLayout.LayoutParams(-1, -1)
                else FrameLayout.LayoutParams(-1, -2, Gravity.CENTER)
                box.addView(clip, lp)
                box
            },
            update = { box ->
                val v = box.getChildAt(0) as ClipView
                v.startMs = startMs
                v.endMs = endMs
                if (v.tick != tick) { v.tick = tick; v.restart() }
            },
            modifier = modifier
        )
    }
}
