package com.jackdev.bluelight

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class BlueNotificationService : NotificationListenerService() {
    override fun onListenerConnected() { refresh() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { refresh() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refresh() }
    private fun refresh() {
        NotifState.count = try { activeNotifications?.count { it.isClearable } ?: 0 } catch (e: Exception) { 0 }
    }
}

class OverlayService : Service() {
    private var wm: WindowManager? = null
    private var tv: TextView? = null
    private val h = Handler(Looper.getMainLooper())
    private var frames = 0

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 1000) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (tv == null && Settings.canDrawOverlays(this)) build()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bl", "Blue Light", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "bl")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Blue Light: monitor activo")
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun build() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val t = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(14, 8, 14, 8)
            setBackgroundColor(Color.argb(153, 0, 0, 0))
            alpha = 0.5f
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 16; y = 16 }
        wm?.addView(t, lp)
        tv = t
        frames = 0
        Choreographer.getInstance().postFrameCallback(frameCb)
        h.post(tick)
    }

    private fun update() {
        val sp = getSharedPreferences("blue", MODE_PRIVATE)
        val s = Stats.read(this)
        val sb = StringBuilder()
        if (sp.getBoolean("ovFps", true)) sb.append("PANTALLA ").append(frames).append(" Hz\n")
        frames = 0
        if (sp.getBoolean("ovCpu", true)) sb.append("CPU ").append(s.cpu?.let { "$it%" } ?: "--").append('\n')
        if (sp.getBoolean("ovGpu", true)) sb.append("GPU ").append(s.gpu?.let { "$it%" } ?: "--").append('\n')
        if (sp.getBoolean("ovRam", true)) sb.append("RAM ").append(s.ram).append("%\n")
        if (sp.getBoolean("ovTemp", true)) sb.append("TEMP ").append(s.temp?.let { "${it.toInt()}°C" } ?: "--")
        tv?.text = sb.toString().trimEnd()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        try { tv?.let { wm?.removeView(it) } } catch (e: Exception) { }
        tv = null
        super.onDestroy()
    }
}
