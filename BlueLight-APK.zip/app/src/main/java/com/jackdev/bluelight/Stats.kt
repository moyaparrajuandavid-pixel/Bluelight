package com.jackdev.bluelight

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.io.File

data class Sys(val cpu: Int?, val gpu: Int?, val ram: Int, val temp: Float?)

object Stats {
    private var lastTotal = 0L
    private var lastIdle = 0L

    fun read(ctx: Context): Sys {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val ram = if (mi.totalMem > 0) (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt() else 0
        val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        return Sys(cpu() ?: cpuFreq(), gpu(), ram, if (t > 0) t / 10f else null)
    }

    private fun cpu(): Int? {
        try {
            val l = File("/proc/stat").bufferedReader().use { it.readLine() } ?: return null
            val p = l.trim().split(Regex("\\s+")).drop(1).map { it.toLong() }
            val idle = p[3] + p[4]
            val total = p.sum()
            val dt = total - lastTotal
            val di = idle - lastIdle
            lastTotal = total
            lastIdle = idle
            return if (dt <= 0) null else (100 * (dt - di) / dt).toInt().coerceIn(0, 100)
        } catch (e: Exception) {
            return null
        }
    }

    private fun cpuFreq(): Int? {
        try {
            var sum = 0.0
            var n = 0
            for (i in 0 until Runtime.getRuntime().availableProcessors()) {
                val cur = File("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq").readText().trim().toDouble()
                val max = File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").readText().trim().toDouble()
                sum += cur / max
                n++
            }
            return if (n > 0) (100 * sum / n).toInt().coerceIn(0, 100) else null
        } catch (e: Exception) {
            return null
        }
    }

    private fun gpu(): Int? {
        try {
            val s = File("/sys/class/kgsl/kgsl-3d0/gpubusy").readText().trim().split(Regex("\\s+"))
            val a = s[0].toLong()
            val b = s[1].toLong()
            return if (b > 0) (100 * a / b).toInt().coerceIn(0, 100) else 0
        } catch (e: Exception) {
            return null
        }
    }
}
