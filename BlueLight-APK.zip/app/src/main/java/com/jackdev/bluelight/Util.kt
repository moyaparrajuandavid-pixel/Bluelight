package com.jackdev.bluelight

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadata
import android.media.MediaMetadataRetriever
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.provider.Settings
import android.view.InputDevice
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(192, 192).asImageBitmap()) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, pkg: String): Boolean {
    val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try { ctx.startActivity(i); true } catch (e: Exception) { false }
}

fun launchGame(ctx: Context, st: AppState, g: Game) {
    if (st.ovOn && Settings.canDrawOverlays(ctx)) {
        try { ctx.startForegroundService(Intent(ctx, OverlayService::class.java)) } catch (e: Exception) { }
    }
    if (g.rom == null) { launchApp(ctx, g.pkg); return }
    val i = Intent(Intent.ACTION_VIEW)
        .setPackage(g.pkg)
        .setDataAndType(Uri.parse(g.rom), "*/*")
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try { ctx.startActivity(i) } catch (e: Exception) { launchApp(ctx, g.pkg) }
}

fun persist(ctx: Context, u: Uri) {
    try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
}

/** Carga una imagen respetando la rotación de la foto (EXIF). */
fun loadRaw(ctx: Context, uri: String, maxSide: Int): Bitmap? = try {
    val u = Uri.parse(uri)
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > maxSide * 2 || o.outHeight / s > maxSide * 2) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    var b = ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }
    if (b != null) {
        val deg = try {
            ctx.contentResolver.openInputStream(u)?.use { ins ->
                when (ExifInterface(ins).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }
        if (deg != 0f) b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg) }, true)
    }
    b
} catch (e: Exception) { null }

fun loadBitmap(ctx: Context, uri: String, maxSide: Int): ImageBitmap? = loadRaw(ctx, uri, maxSide)?.asImageBitmap()

fun videoDurationMs(ctx: Context, u: Uri): Long = try {
    val r = MediaMetadataRetriever()
    r.setDataSource(ctx, u)
    val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
    r.release()
    d
} catch (e: Exception) { 0L }

@Composable
fun UriImage(uri: String?, maxSide: Int, modifier: Modifier, scale: ContentScale = ContentScale.Crop) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, uri) {
        value = if (uri == null) null else withContext(Dispatchers.IO) { loadBitmap(ctx, uri, maxSide) }
    }
    bmp?.let { Image(it, null, modifier, contentScale = scale) }
}

data class Track(
    val title: String, val artist: String, val playing: Boolean,
    val ctl: MediaController, val art: ImageBitmap?, val pkg: String
)

fun currentTrack(ctx: Context): Track? = try {
    val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    val c = msm.getActiveSessions(ComponentName(ctx, BlueNotificationService::class.java)).firstOrNull()
    if (c == null) null else {
        val md = c.metadata
        val art = (md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON))?.asImageBitmap()
        Track(
            md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Reproduciendo",
            md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
            c.playbackState?.state == PlaybackState.STATE_PLAYING,
            c, art, c.packageName
        )
    }
} catch (e: Exception) { null }

fun isPad(d: InputDevice?): Boolean =
    d != null && (d.sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD

fun padName(n: String): String {
    val l = n.lowercase()
    return when {
        l.contains("xbox") -> "Xbox"
        l.contains("dualsense") -> "PlayStation 5"
        l.contains("dualshock") || l.contains("wireless controller") || l.contains("playstation") -> "PlayStation"
        else -> n
    }
}
