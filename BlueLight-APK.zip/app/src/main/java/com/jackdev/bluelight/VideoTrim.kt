package com.jackdev.bluelight

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private fun fmt(sec: Float): String {
    val t = sec.toInt()
    return "%d:%02d".format(t / 60, t % 60)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoTrimScreen(file: String, onCancel: () -> Unit, onOk: (Int, Int) -> Unit) {
    val ctx = LocalContext.current
    val durMs = remember(file) { videoDurationMs(ctx, Uri.parse(file)) }
    val dur = (durMs / 1000f).coerceAtLeast(2f)
    var a by remember { mutableFloatStateOf(0f) }
    var b by remember { mutableFloatStateOf(minOf(dur, 20f)) }
    var tick by remember { mutableIntStateOf(0) }
    BackHandler(onBack = onCancel)

    Row(
        Modifier.fillMaxSize().background(Color(0xF2051434))
            .pointerInput(Unit) { detectTapGestures { } }.padding(16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(width = 300.dp, height = 170.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black)) {
            ClipVideo(file, (a * 1000).toInt(), (b * 1000).toInt(), 2, Modifier.fillMaxSize(), tick)
        }
        Spacer(Modifier.width(24.dp))
        Column(Modifier.width(320.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Recorta tu video", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                "Inicio ${fmt(a)}   Fin ${fmt(b)}   Dura ${(b - a).toInt()} s (máx. 20 s)",
                color = Color(0xEEFFFFFF), fontSize = 14.sp
            )
            RangeSlider(
                value = a..b,
                onValueChange = { r ->
                    var na = r.start
                    var nb = r.endInclusive
                    if (nb - na > 20f) { if (na != a) nb = na + 20f else na = nb - 20f }
                    if (nb - na < 1f) { if (na != a) na = (nb - 1f).coerceAtLeast(0f) else nb = (na + 1f).coerceAtMost(dur) }
                    a = na
                    b = nb
                },
                valueRange = 0f..dur,
                onValueChangeFinished = { tick++ }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillBtn("Ver") { tick++ }
                PillBtn("OK ✅") { onOk((a * 1000).toInt(), (b * 1000).toInt()) }
                PillBtn("Cancelar", onCancel)
            }
        }
    }
}
