package com.jackdev.bluelight

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Blue = Color(0xFF2D8CFF)

@Composable
fun Focusable(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(8.dp),
    onClick: () -> Unit,
    content: @Composable BoxScope.(Boolean) -> Unit
) {
    var f by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (f) 1.12f else 1f, label = "s")
    Box(
        modifier
            .scale(s)
            .clip(shape)
            .border(if (f) 2.dp else 0.dp, if (f) Color.White else Color.Transparent, shape)
            .onFocusChanged { f = it.hasFocus }
            .clickable(onClick = onClick)
    ) { content(f) }
}

@Composable
fun CircleBtn(icon: ImageVector, size: Dp = 48.dp, onClick: () -> Unit) {
    Focusable(Modifier.size(size), CircleShape, onClick) { f ->
        Box(
            Modifier.fillMaxSize().background(if (f) Blue else Color(0x33FFFFFF)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, Modifier.size(size * 0.5f), tint = Color.White) }
    }
}

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(Color(0x66081B3D)).padding(14.dp),
        content = content
    )
}

@Composable
fun Tile(label: String, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Focusable(Modifier.size(150.dp), RoundedCornerShape(8.dp), onClick) {
            Box(Modifier.fillMaxSize().background(Color(0x44FFFFFF)), content = content)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            label, color = Color.White, fontSize = 13.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.width(150.dp), textAlign = TextAlign.Center
        )
    }
}

@Composable
fun StatBar(label: String, v: Int?) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 11.sp, modifier = Modifier.width(40.dp))
        LinearProgressIndicator(
            progress = { (v ?: 0) / 100f },
            modifier = Modifier.weight(1f).height(5.dp).clip(CircleShape),
            color = Blue, trackColor = Color(0x33FFFFFF)
        )
        Text(
            if (v == null) "--" else "$v%", color = Color.White, fontSize = 11.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.width(40.dp), textAlign = TextAlign.End
        )
    }
}

@Composable
fun HomeScreen(st: AppState, apps: List<AppInfo>, onSettings: () -> Unit, onAdd: () -> Unit) {
    val ctx = LocalContext.current
    var allApps by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var pickDock by remember { mutableStateOf(false) }
    var pickMusic by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(Date()) }
    var sys by remember { mutableStateOf<Sys?>(null) }
    var track by remember { mutableStateOf<Track?>(null) }

    BackHandler { if (editing) editing = false else allApps = false }

    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            sys = withContext(Dispatchers.IO) { Stats.read(ctx) }
            track = currentTrack(ctx)
            delay(1500)
        }
    }

    val byPkg = remember(apps) { apps.associateBy { it.pkg } }
    val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
    val dateStr = SimpleDateFormat("EEE d MMM", Locale.getDefault()).format(now)

    fun openMusic() {
        val p = st.musicPkg
        if (p == null || !launchApp(ctx, p)) pickMusic = true
    }

    @Composable
    fun Clock() {
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(horizontal = 12.dp)) {
            Text(timeStr, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(dateStr, color = Color(0xCCFFFFFF), fontSize = 11.sp)
        }
    }

    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF031A47), Color(0xFF0A5BC4), Color(0xFF031A47)))
            )
        )
        if (st.wallpaper != null) {
            UriImage(st.wallpaper, 1920, Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Color(0x66000000)))
        }

        Row(
            Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Barra izquierda
            Column(
                Modifier.fillMaxHeight().clip(RoundedCornerShape(30.dp)).background(Color(0x55081B3D)).padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)
            ) {
                CircleBtn(Icons.Rounded.Language) {
                    ctx.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
                CircleBtn(Icons.Rounded.MusicNote) { openMusic() }
                CircleBtn(Icons.Rounded.Apps) { allApps = !allApps }
                CircleBtn(Icons.Rounded.Edit) { editing = !editing }
                CircleBtn(Icons.Rounded.Settings, onClick = onSettings)
            }

            // Centro
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (st.clockLeft) Clock()
                    LazyRow(
                        Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        contentPadding = PaddingValues(horizontal = 8.dp)
                    ) {
                        items(st.dock.toList()) { pkg ->
                            val a = byPkg[pkg]
                            if (a != null) {
                                Focusable(Modifier.size(46.dp), RoundedCornerShape(10.dp), {
                                    if (editing) { st.dock.remove(pkg); st.save() } else launchApp(ctx, pkg)
                                }) {
                                    Image(a.icon, a.label, Modifier.fillMaxSize().padding(2.dp))
                                    if (editing) {
                                        Box(
                                            Modifier.align(Alignment.TopEnd).size(16.dp).background(Color.Red, CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) { Icon(Icons.Rounded.Close, null, Modifier.size(12.dp), tint = Color.White) }
                                    }
                                }
                            }
                        }
                        if (editing) {
                            item {
                                CircleBtn(Icons.Rounded.Add, 44.dp) { pickDock = true }
                            }
                        }
                    }
                    if (!st.clockLeft) Clock()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Notifications, null, tint = Color.White, modifier = Modifier.size(22.dp))
                        if (NotifState.count > 0) {
                            Text("${NotifState.count}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(Modifier.weight(1f))
                Text(
                    if (allApps) "Aplicaciones" else "Juegos",
                    color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 12.dp)
                )
                LazyRow(
                    Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!allApps) {
                        item {
                            Tile("Agregar juego", onAdd) {
                                Icon(Icons.Rounded.Add, null, Modifier.align(Alignment.Center).size(48.dp), tint = Color.White)
                            }
                        }
                        items(st.games.toList(), key = { it.id }) { g ->
                            Tile(g.name, { launchGame(ctx, st, g) }) {
                                if (g.cover != null) {
                                    UriImage(g.cover, 300, Modifier.fillMaxSize())
                                } else {
                                    val ic = byPkg[g.pkg]?.icon
                                    if (ic != null) Image(ic, null, Modifier.align(Alignment.Center).size(72.dp))
                                }
                            }
                        }
                    } else {
                        val gamePkgs = st.games.filter { it.rom == null }.map { it.pkg }.toSet()
                        items(apps.filter { it.pkg !in gamePkgs }, key = { it.pkg }) { a ->
                            Tile(a.label, { launchApp(ctx, a.pkg) }) {
                                Image(a.icon, null, Modifier.align(Alignment.Center).size(72.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
            }

            // Panel derecho
            Column(
                Modifier.width(240.dp).fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)
            ) {
                val tr = track
                Panel(Modifier.fillMaxWidth().clickable { openMusic() }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(52.dp).clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(listOf(Blue, Color(0xFF0B3D91)))),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Rounded.MusicNote, null, tint = Color.White) }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                tr?.title ?: "Nada sonando", color = Color.White, fontSize = 14.sp,
                                fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                if (tr == null) "Toca para abrir tu reproductor" else tr.artist,
                                color = Color(0xCCFFFFFF), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    if (tr != null) {
                        Row(
                            Modifier.fillMaxWidth().padding(top = 8.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircleBtn(Icons.Rounded.SkipPrevious, 36.dp) { tr.ctl.transportControls.skipToPrevious() }
                            CircleBtn(if (tr.playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, 40.dp) {
                                if (tr.playing) tr.ctl.transportControls.pause() else tr.ctl.transportControls.play()
                            }
                            CircleBtn(Icons.Rounded.SkipNext, 36.dp) { tr.ctl.transportControls.skipToNext() }
                        }
                    }
                }
                Panel(Modifier.fillMaxWidth()) {
                    val s = sys
                    if (s != null) {
                        if (st.ovCpu) StatBar("CPU", s.cpu)
                        if (st.ovGpu) StatBar("GPU", s.gpu)
                        if (st.ovRam) StatBar("RAM", s.ram)
                        if (st.ovTemp) {
                            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("TEMP", color = Color.White, fontSize = 11.sp)
                                Text(
                                    s.temp?.let { "${it.toInt()}°C" } ?: "--",
                                    color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (pickDock) {
        AppPickerDialog(apps, {
            if (it.pkg !in st.dock) st.dock.add(it.pkg)
            st.save(); pickDock = false
        }, { pickDock = false })
    }
    if (pickMusic) {
        AppPickerDialog(apps, {
            st.musicPkg = it.pkg; st.save(); pickMusic = false; launchApp(ctx, it.pkg)
        }, { pickMusic = false })
    }
}
