package com.jackdev.bluelight

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.app.NotificationManagerCompat
import java.util.UUID

@Composable
fun AppPickerDialog(apps: List<AppInfo>, onPick: (AppInfo) -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.width(420.dp).height(320.dp).clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0B2250)).padding(12.dp)
        ) {
            Text("Elige una app", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.fillMaxSize()) {
                items(apps, key = { it.pkg }) { a ->
                    Focusable(Modifier.fillMaxWidth(), RoundedCornerShape(8.dp), { onPick(a) }) {
                        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Image(a.icon, null, Modifier.size(36.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(a.label, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SRow(title: String, sub: String? = null, trailing: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    Focusable(Modifier.fillMaxWidth(), RoundedCornerShape(10.dp), onClick) {
        Row(
            Modifier.fillMaxWidth().background(Color(0x33FFFFFF)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 16.sp)
                if (sub != null) Text(sub, color = Color(0xAAFFFFFF), fontSize = 12.sp)
            }
            trailing?.invoke()
        }
    }
}

@Composable
fun TRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    SRow(title, null, { Switch(checked = checked, onCheckedChange = null) }) { onChange(!checked) }
}

@Composable
fun SettingsScreen(st: AppState, apps: List<AppInfo>, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var pickMusic by remember { mutableStateOf(false) }
    val wall = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { persist(ctx, u); st.wallpaper = u.toString(); st.save() }
    }
    BackHandler { st.save(); onBack() }
    val scales = listOf(0.8f, 0.9f, 1f, 1.1f, 1.2f, 1.3f)
    val notifOn = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun open(i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } }

    LazyColumn(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF031A47), Color(0xFF06142E)))),
        contentPadding = PaddingValues(horizontal = 48.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Ajustes", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }

        item { SRow("Fondo de pantalla", "Elegir una imagen de la galería") { wall.launch(arrayOf("image/*")) } }
        if (st.wallpaper != null) {
            item { SRow("Quitar fondo") { st.wallpaper = null; st.save() } }
        }
        item {
            SRow("Skin", "Blue Light (predeterminada) · las skins se podrán descargar aquí") {
                Toast.makeText(ctx, "Las skins llegan pronto", Toast.LENGTH_SHORT).show()
            }
        }
        item {
            SRow("Tamaño de la pantalla: ${(st.scale * 100).toInt()}%", "Toca para acercar o alejar") {
                val i = scales.indexOfFirst { it >= st.scale - 0.01f }.let { if (it < 0) 0 else it }
                st.scale = scales[(i + 1) % scales.size]; st.save()
            }
        }
        item { TRow("Mostrar intro al iniciar", st.showIntro) { st.showIntro = it; st.save() } }
        item { TRow("Hora a la izquierda", st.clockLeft) { st.clockLeft = it; st.save() } }

        item { Text("Monitor de rendimiento", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item { TRow("Mostrar monitor sobre los juegos", st.ovOn) { st.ovOn = it; st.save() } }
        item { TRow("Frecuencia de pantalla (Hz)", st.ovFps) { st.ovFps = it; st.save() } }
        item { TRow("CPU", st.ovCpu) { st.ovCpu = it; st.save() } }
        item { TRow("GPU", st.ovGpu) { st.ovGpu = it; st.save() } }
        item { TRow("RAM", st.ovRam) { st.ovRam = it; st.save() } }
        item { TRow("Temperatura", st.ovTemp) { st.ovTemp = it; st.save() } }
        item {
            SRow(
                "Permiso para mostrar sobre otras apps",
                if (Settings.canDrawOverlays(ctx)) "Concedido ✅" else "Falta: toca para darlo"
            ) {
                open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }
        }

        item { Text("Música y notificaciones", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item {
            SRow("Reproductor de música", st.musicPkg?.let { p -> apps.find { it.pkg == p }?.label } ?: "Sin elegir") {
                pickMusic = true
            }
        }
        item {
            SRow("Acceso a notificaciones y canción", if (notifOn) "Activado ✅" else "Falta: toca para activarlo") {
                open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }

        item { Text("Sistema", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item {
            SRow("Usar Blue Light como inicio de Android", "Es opcional; aquí eliges el inicio") {
                open(Intent(Settings.ACTION_HOME_SETTINGS))
            }
        }
        item { SRow("Mando", "Se detecta solo al conectarlo. Cruceta para moverte y A para elegir") { } }

        item { Text("Juegos", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        items(st.games.toList(), key = { it.id }) { g ->
            SRow(g.name, "Toca para eliminar") { st.games.remove(g); st.save() }
        }
    }

    if (pickMusic) {
        AppPickerDialog(apps, { st.musicPkg = it.pkg; st.save(); pickMusic = false }, { pickMusic = false })
    }
}

@Composable
fun AddGameScreen(st: AppState, apps: List<AppInfo>, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var cover by remember { mutableStateOf<String?>(null) }
    var pkg by remember { mutableStateOf<String?>(null) }
    var rom by remember { mutableStateOf<String?>(null) }
    var pick by remember { mutableStateOf(false) }
    val coverL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { persist(ctx, u); cover = u.toString() }
    }
    val romL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { persist(ctx, u); rom = u.toString() }
    }
    BackHandler(onBack = onBack)

    LazyColumn(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF031A47), Color(0xFF06142E)))),
        contentPadding = PaddingValues(horizontal = 48.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Agregar juego", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        item {
            OutlinedTextField(
                value = name, onValueChange = { name = it }, singleLine = true,
                label = { Text("Nombre del juego") }, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            SRow("Carátula", if (cover == null) "Elegir imagen (opcional)" else "Imagen elegida ✅") {
                coverL.launch(arrayOf("image/*"))
            }
        }
        item {
            SRow(
                "Emulador o app",
                pkg?.let { p -> apps.find { it.pkg == p }?.label } ?: "Elegir la app que lo abre"
            ) { pick = true }
        }
        item {
            SRow(
                "Archivo del juego",
                if (rom == null) "Opcional: sin archivo se abre la app directamente (juegos de Android)" else "Archivo elegido ✅"
            ) { romL.launch(arrayOf("*/*")) }
        }
        item {
            SRow("Guardar") {
                val p = pkg
                if (name.isBlank() || p == null) {
                    Toast.makeText(ctx, "Falta el nombre o la app", Toast.LENGTH_SHORT).show()
                } else {
                    st.games.add(Game(UUID.randomUUID().toString(), name.trim(), cover, p, rom))
                    st.save()
                    onBack()
                }
            }
        }
    }

    if (pick) AppPickerDialog(apps, { pkg = it.pkg; pick = false }, { pick = false })
}
