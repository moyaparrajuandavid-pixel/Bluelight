package com.jackdev.bluelight

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.provider.Settings
import android.view.InputDevice
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(val label: String, val pkg: String, val icon: ImageBitmap)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(96, 96).asImageBitmap()) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, pkg: String): Boolean {
    val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try { ctx.startActivity(i); true } catch (e: Exception) { false }
}

fun launchGame(ctx: Context, st: AppState, g: Game) {
    if (st.ovOn && Settings.canDrawOverlays(ctx)) {
        try { ctx.startForegroundService(Intent(ctx, OverlayService::class.java)) } catch (e: Exception) { }
    }
    if (g.rom == null) { launchApp(ctx, g.pkg); return }
    val i = Intent(Intent.ACTION_VIEW)
        .setPackage(g.pkg)
        .setDataAndType(Uri.parse(g.rom), "*/*")
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try { ctx.startActivity(i) } catch (e: Exception) { launchApp(ctx, g.pkg) }
}

fun persist(ctx: Context, u: Uri) {
    try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
}

fun loadBitmap(ctx: Context, uri: String, maxSide: Int): ImageBitmap? = try {
    val u = Uri.parse(uri)
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > maxSide * 2 || o.outHeight / s > maxSide * 2) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o2) }?.asImageBitmap()
} catch (e: Exception) { null }

@Composable
fun UriImage(uri: String?, maxSide: Int, modifier: Modifier, scale: ContentScale = ContentScale.Crop) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, uri) {
        value = if (uri == null) null else withContext(Dispatchers.IO) { loadBitmap(ctx, uri, maxSide) }
    }
    bmp?.let { Image(it, null, modifier, contentScale = scale) }
}

data class Track(val title: String, val artist: String, val playing: Boolean, val ctl: MediaController)

fun currentTrack(ctx: Context): Track? = try {
    val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    val c = msm.getActiveSessions(ComponentName(ctx, BlueNotificationService::class.java)).firstOrNull()
    if (c == null) null else Track(
        c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Reproduciendo",
        c.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
        c.playbackState?.state == PlaybackState.STATE_PLAYING,
        c
    )
} catch (e: Exception) { null }

fun isPad(d: InputDevice?): Boolean =
    d != null && (d.sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD

fun padName(n: String): String {
    val l = n.lowercase()
    return when {
        l.contains("xbox") -> "Xbox"
        l.contains("dualsense") -> "PlayStation 5"
        l.contains("dualshock") || l.contains("wireless controller") || l.contains("playstation") -> "PlayStation"
        else -> n
    }
}
